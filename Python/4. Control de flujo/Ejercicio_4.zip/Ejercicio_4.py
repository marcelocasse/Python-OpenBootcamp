inverso = range(101)
for x in inverso[::-1]:
    print(x)